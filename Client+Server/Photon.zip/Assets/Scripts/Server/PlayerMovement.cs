﻿using UnityEngine;
using System.Collections;

public class PlayerMovement : MonoBehaviour
{
    //this movement only enabled my player
    // Use this for initialization

    float speed = 10f;
    float jumpSpeed = 5f;
    float VerticalVelocity = 0;
    Vector3 direction = Vector3.zero;
    CharacterController cc;
    Animator anim;
    CapsuleCollider capsCollier;
    void Start()
    {
        cc = GetComponent<CharacterController>();
        //anim = GetComponent<Animator>();
        //capsCollier = (CapsuleCollider)GetComponent<Collider>();
    }

    // Update is called once per frame
    void Update()
    {
        // wasd forward/back, left right movement
        direction = transform.rotation * new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));

        if (direction.magnitude > 1f)
        {
            direction = direction.normalized;
        }
        //anim.SetFloat("Speed", direction.magnitude);

        if (cc.isGrounded && Input.GetButton("Jump"))
        {
            VerticalVelocity = jumpSpeed;
        }
        //else
        //{
        //    anim.SetBool("Jumping", true);
        //}
    }
    // fixed is called one per physics loop
    // do all movement and other physics stuff here
    void FixedUpdate()
    {
        Vector3 dist = direction * speed * Time.deltaTime;
        if (cc.isGrounded && VerticalVelocity < 0)
        {
            //anim.SetBool("Jumping", false);
            VerticalVelocity += Physics.gravity.y * Time.deltaTime;
        }
        else {
            //if(Mathf.Abs(VerticalVelocity) > jumpSpeed * 0.75f)
            //{
            //    anim.SetBool("Jumping", true);
            //}
            VerticalVelocity += Physics.gravity.y * Time.deltaTime;

        }
        dist.y = VerticalVelocity * Time.deltaTime;
        cc.Move(dist);
    }
}