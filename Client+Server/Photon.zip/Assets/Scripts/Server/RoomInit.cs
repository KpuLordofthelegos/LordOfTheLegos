﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;

public class RoomInit : MonoBehaviour {
    public Text txtConnect;
    public Text txtLogMsg;
    private PhotonView pv;

    void Awake()
    {
        pv = GetComponent<PhotonView>();
        PhotonNetwork.isMessageQueueRunning = true;
        GetConnectPlayerCount();
    }
    void Start()
    {
        string msg = "\n<color=#00ff00>[" + PhotonNetwork.player.name + "] Connected</color>";
        pv.RPC("LogMsg", PhotonTargets.All, msg);
    }
    void GetConnectPlayerCount()
    {
        Room currRoom = PhotonNetwork.room;
        txtConnect.text = currRoom.playerCount.ToString() + "/" + currRoom.maxPlayers.ToString();
    }
    
	void OnPhotonPlayerConnected(PhotonPlayer newPlayer)
    {
        GetConnectPlayerCount();
    }
    void OnPhotonPlayerDisconnected(PhotonPlayer outPlayer)
    {
        GetConnectPlayerCount();
    }
    [PunRPC]
    void LogMsg(string msg)
    {
        txtLogMsg.text = txtLogMsg.text + msg;
    }
    public void OnClickExitRoom()
    {
        string msg = "\n<color=#ff0000>[" + PhotonNetwork.player.name + "] Disconnected</color>";
        pv.RPC("LogMsg", PhotonTargets.All, msg);
        PhotonNetwork.LeaveRoom();
    }
    public void OnClickJoinGameRoom()
    {
        PlayerPrefs.SetString("User_ID", PhotonNetwork.player.name);
        StartCoroutine(this.Game());
    }

    IEnumerator Game()
    {
        PhotonNetwork.isMessageQueueRunning = false;
        AsyncOperation ao = SceneManager.LoadSceneAsync("Game");
        yield return ao;
    }
    void OnLeftRoom()
    {
        SceneManager.LoadScene("Lobby");
    }

}
