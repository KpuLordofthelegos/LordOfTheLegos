﻿using UnityEngine;
using System.Collections;

public class GameInit : MonoBehaviour {
    public GameObject standbyCamera;
    public string version = "v1.0";
    public bool offlineMode = false;
    public float respawnTimer = 0;
    void Start()
    {
        Connect();
    }
    void Connect()
    {
        if (offlineMode)
        {
            PhotonNetwork.offlineMode = true;
            OnJoinedLobby(); 
        }
        else{
            PhotonNetwork.ConnectUsingSettings(version);
        }
    }

    void OnJoinedLobby()
    {
        Debug.Log("OnJoinedLobby");
        PhotonNetwork.JoinRandomRoom();
    }

    void OnPhotonRandomJoinFailed()
    {
        Debug.Log("OnPhotonRandomJoinFailed");
        PhotonNetwork.CreateRoom(null);
    }
    void OnJoinedRoom()
    {
        Debug.Log("OnJoinedRoom");
        CreatePlayer();
    }
        void CreatePlayer()
    {

        float pos = Random.Range(0.0f, 50.0f);
        GameObject myPlayer = PhotonNetwork.Instantiate("GamePlayer", new Vector3(pos, 0.0f, pos), Quaternion.identity, 0);
        standbyCamera.SetActive(false);

        //((MonoBehaviour)myPlayer.GetComponent("FPSInputController")).enabled = true;
        ((MonoBehaviour)myPlayer.GetComponent("MouseLook")).enabled = true;
        //((MonoBehaviour)myPlayer.GetComponent("CharacterMotor")).enabled = true;
        ((MonoBehaviour)myPlayer.GetComponent("PlayerMovement")).enabled = true;
        ((MonoBehaviour)myPlayer.GetComponent("PlayerShooting")).enabled = true;
        myPlayer.transform.FindChild("Main Camera").gameObject.SetActive(true);
    }
    void Update()
    {
        if(respawnTimer > 0)
        {
            respawnTimer -= Time.deltaTime;
            if(respawnTimer <= 0)
            {
                //Time to respawn the Player
                CreatePlayer();
            }
        }
    }
    //void OnPhotonPlayerConnected(PhotonPlayer newPlayer)
    //{
    //    GetConnectPlayerCount();
    //}
    //void GetConnectPlayerCount()
    //{
    //    Room currRoom = PhotonNetwork.room;
    //}
    void OnGUI()
    {
        GUILayout.Label(PhotonNetwork.connectionStateDetailed.ToString());
    }
}
