﻿using UnityEngine;
using System.Collections;

public class PlayerShooting : MonoBehaviour {
    public float fireRate = 0.5f;
    float cooldown = 0;
    public float damage = 25f;
	void Update () {
        cooldown -= Time.deltaTime;
        if (Input.GetButton("Fire1")){
            //player wants to shoot
            Fire();
        }
	}
    void Fire(){
        if(cooldown > 0){
            return;
        }
        Debug.Log("Firing Gun");

        Ray ray = new Ray(Camera.main.transform.position, Camera.main.transform.forward);
        Transform hitTransform;
        Vector3 hitPoint;

        hitTransform = FindClosestHitInfo(ray, out hitPoint);

        if(hitTransform != null)
        {
            Debug.Log("We hit : " + hitTransform.transform.name);
            //after could do a special(particle) effects at the hit location
            //DoRicochetEffectAt(hitPoint);
            Health h = hitTransform.transform.GetComponent<Health>();

            while(h == null && hitTransform.parent){
                hitTransform = hitTransform.parent;
                h = hitTransform.GetComponent<Health>();
            }
            //Once we reach here, hitTransform may not be the hitTransform we started with;
            if (h != null)
            {
                //this next line is the equivalent of calling
                //except more "networky"
                PhotonView pv = h.GetComponent<PhotonView>();
                if (pv == null)
                {
                    Debug.LogError("Freak out");
                }
                else {
                    h.GetComponent<PhotonView>().RPC("TakeDamage", PhotonTargets.All, damage);
                    //h.TakeDamage(damage);
                }
            }
        }

        cooldown = fireRate;
    }
    Transform FindClosestHitInfo(Ray ray, out Vector3 hitPoint){
        RaycastHit[] hits = Physics.RaycastAll(ray);
        Transform closestHit = null;
        float distance = 0;
        hitPoint = Vector3.zero;

        foreach (RaycastHit hit in hits) {
            if (Input.GetMouseButtonDown(0))
            {
                if (hit.transform != this.transform && (closestHit == null) || hit.distance < distance)
                {
                    // we have hit something that is
                    // a; not us
                    // b; the first thing we hit
                    // c; if not b, is at least closer then the previous closest thing
                    closestHit = hit.transform;
                    distance = hit.distance;
                    hitPoint = hit.point;
                }
            }
        }
        //closestHit is now either still null(we hit nothing) or it contains the cloest thing that is a vaild thing to hit
        return closestHit;
    }
}
