﻿using UnityEngine;
using System.Collections;

public class PlayerMove : MonoBehaviour
{
    public CharacterController CC;

    float MoveSpeed;
    float RotSpeed;
    Vector3 V3;
    void Start()
    {
        this.enabled = GetComponent<PhotonView>().isMine;
        MoveSpeed = 5;
        RotSpeed = 2f;

    }
    void Update()
    {
        V3 = new Vector3(0, Input.GetAxis("Mouse X"), 0);
        transform.Rotate(V3 * RotSpeed);
        if (Input.GetKey(KeyCode.W))
        {
            CC.Move ( transform.forward*MoveSpeed*Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.S))
        {
            CC.Move(transform.forward * -1f * MoveSpeed * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.A))
        {
            CC.Move(transform.right * -1f * MoveSpeed * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.D))
        {
            CC.Move(transform.right * MoveSpeed * Time.deltaTime);
        }
    }
}
//public class PlayerMove : MonoBehaviour
//{
//    private float h = 0.0f;
//    private float v = 0.0f;

//    private Transform tr;
//    private CharacterController controller;

//    public float moveSpeed = 10.0f;
//    public float rotSpeed = 300.0f;
//    private Vector3 movDir = Vector3.zero;
//    void Start()
//    {
//        this.enabled = GetComponent<PhotonView>().isMine;
//        tr = GetComponent<Transform>();
//        controller = GetComponent<CharacterController>();
//    }

//    void Update()
//    {
//        h = Input.GetAxis("Horizontal");
//        v = Input.GetAxis("Vertical");
//        tr.Rotate(Vector3.up * Input.GetAxis("Mouse X") * rotSpeed * Time.deltaTime);
//        movDir = (tr.forward * v) + (tr.right * h);
//        controller.Move(movDir * moveSpeed * Time.deltaTime);
//    }
//}
//public class PlayerMove : MonoBehaviour
//{
//    public float moveSpeed = 5.0f;

//    private Rigidbody rbody;
//    private Transform tr;
//    private float h, v;
//    // Use this for initialization

//    private PhotonView pv = null;
//    public Transform camPivot;

//    private Vector3 currPos = Vector3.zero;
//    private Quaternion currRot = Quaternion.identity;
//    void Awake()
//    {
//        rbody = GetComponent<Rigidbody>();
//        tr = GetComponent<Transform>();
//        rbody.centerOfMass = new Vector3(0.0f, -0.5f, 0.0f);

//        pv = GetComponent<PhotonView>();
//        pv.synchronization = ViewSynchronization.UnreliableOnChange;
//        pv.ObservedComponents[0] = this;
//        if (pv.isMine)
//        {
//            Camera.main.GetComponent<SmoothFollow>().target = camPivot;
//        }
//        currPos = tr.position;
//        currRot = tr.rotation;
//    }
//    void OnPhotonSerializeView(PhotonStream stream, PhotonMessageInfo info)
//    {
//        if (stream.isWriting)
//        {
//            stream.SendNext(tr.position);
//            stream.SendNext(tr.rotation);
//        }
//        else
//        {
//            currPos = (Vector3)stream.ReceiveNext();
//            currRot = (Quaternion)stream.ReceiveNext();
//        }
//    }
//    // Update is called once per frame
//    void Update()
//    {
//        if (pv.isMine) 
//        {
//            h = Input.GetAxis("Horizontal");
//            v = Input.GetAxis("Vertical");

//            Vector3 moveDir = (Vector3.forward * v) + (Vector3.right * h);
//            tr.Translate(moveDir * Time.deltaTime * moveSpeed, Space.Self);
//        }
//        else //원격 플레이어일 때 수행
//        {
//            tr.position = Vector3.Lerp(tr.position, currPos, Time.deltaTime * 1.0f);
//            tr.rotation = Quaternion.Slerp(tr.rotation, currRot, Time.deltaTime * 1.0f);
//        }
//    }
//}
