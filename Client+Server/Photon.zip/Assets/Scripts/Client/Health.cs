﻿using UnityEngine;
using System.Collections;

public class Health : MonoBehaviour {

    public float hitPoints = 100f;
    float currentHitPoints;
    //float FreezeTimer = 0f;
    // Use this for initialization
    void Start () {
        currentHitPoints = hitPoints;
    }
    void Update()
    {
        if (GameObject.FindWithTag("Player").transform.position.y < -10)
        {
            Die();
            Debug.Log("Dead");
        }
    }

    [PunRPC]
    public void TakeDamage(float amt)
    {
        //FreezeTimer = 3f;
        currentHitPoints -= amt;
        //if (GetComponent<PhotonView>().isMine)
        //{
        //    if (currentHitPoints <= 0 && gameObject.tag == "Player")
        //    {
        //        FreezeTimer -= Time.deltaTime;
        //        if (FreezeTimer > 0)
        //        {
        //            GameObject.FindWithTag("Player").SetActive(false);
        //            currentHitPoints += 10;
        //        }
        //    }
        //    else if (currentHitPoints > 0)
        //    {
        //        GameObject.FindWithTag("Player").SetActive(true);
        //    }
        //}
    }
    void Die()
    {
        if (GetComponent<PhotonView>().instantiationId == 0)
        {
            Destroy(gameObject);
        }
        else {
            if (GetComponent<PhotonView>().isMine)
            {
                if (gameObject.tag == "Player") // this is my actual Player, then initiate the respawn process
                {
                    GameInit nm = GameObject.FindObjectOfType<GameInit>();
                    nm.standbyCamera.SetActive(true);
                    nm.respawnTimer = 5f;
                    //GameObject.Find("StandbyCamera").SetActive(true);
                    //GameObject.FindObjectOfType<GameInit>().respawnTimer = 5f;
                }
                PhotonNetwork.Destroy(gameObject);
            }
        }
    }
    void OnGUI()
    {
        if(GetComponent<PhotonView>().isMine && gameObject.tag == "Player")
        {
            if(GUI.Button(new Rect(Screen.width - 100, 0, 100, 40), "Suicide!"))
            {
                Die();
            }
        }
    }
}
